package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entities.Book;
import com.springrest.springrest.services.LibraryService;

@RestController
public class MyController {
  
	@Autowired
	private LibraryService librarySerivice;
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to Library Management System";
	}
	
	//get the books
	@GetMapping("/Books")
	public List<Book> getBooks()
	{
		return this.librarySerivice.getBooks();
}
	@GetMapping("/Books/{BookId}")
	public Book getBook(@PathVariable String BookId) {
		return this.librarySerivice.getBook(Long.parseLong(BookId));
	}
	
	@PostMapping("/Books")
	public Book addBook(@RequestBody Book book)
	{
		return this.librarySerivice.addBook(book);
	}
	@DeleteMapping("/Books/{BookId}")
	public ResponseEntity<HttpStatus> deleteBook(@PathVariable String BookId) {
		try {
			this.librarySerivice.deleteBook(Long.parseLong(BookId));
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}






