package com.springrest.springrest.services;
import java.util.List;

import com.springrest.springrest.entities.Book;
public interface LibraryService {

	public List<Book> getBooks();
	public Book getBook(long BookId);
	public Book addBook(Book book);
	public void deleteBook(long parseLong);
	
}
