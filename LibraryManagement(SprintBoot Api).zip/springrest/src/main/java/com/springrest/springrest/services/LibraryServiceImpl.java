 package com.springrest.springrest.services;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.springrest.springrest.dao.LibraryDao;
import com.springrest.springrest.entities.Book;

@Service
public class LibraryServiceImpl implements LibraryService{

	@Autowired
	private LibraryDao libraryDao;
	
	
	
	
	//List<Book> list;
	
	public LibraryServiceImpl() {
	
	//list=new ArrayList<>();
	//list.add(new Book(125,"harry potter","JK rowling"));
	//list.add(new Book(123,"harry ","JK rowlin"));
	}
	
	
	
	
	
	@Override
	public List<Book> getBooks() {
		return libraryDao.findAll();
	}








 @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@Override
	public Book getBook(long BookId) {
		
	//	Book b=null;
		//for(Book book:list)
		//{
			//if(book.getId()==BookId)
			//{ 
				//b=book;
				//break;
		//	}
	//}

         return libraryDao.getOne(BookId);
        	 
         }




	@Override
	public Book addBook(Book book) {
	//	list.add(book);
		libraryDao.save(book);
		return book;
	}

	
	@SuppressWarnings("deprecation")
	@Override
	public void deleteBook(long parseLong) {
	//	list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
	 Book entity=libraryDao.getOne(parseLong);
		libraryDao.delete(entity);
	}
}
